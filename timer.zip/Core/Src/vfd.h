/*** 
 * @Author: liubotao
 * @Date: 2022-08-06 09:12:42
 * @LastEditors: liubotao
 * @LastEditTime: 2022-08-06 10:16:21
 * @FilePath: \timer\Core\Src\vfd.h
 * @Description: 
 * @
 */
#ifndef _VFD_H_
#define _VFD_H_

#include "main.h"

#define resetPin GPIO_PIN_10
#define resetPort GPIOB

#define csPin GPIO_PIN_11
#define csPort GPIOB

#define clkPin GPIO_PIN_14
#define clkPort GPIOB

#define dinPin GPIO_PIN_15
#define dinPort GPIOB

	


#define reset(x) x?HAL_GPIO_WritePin(resetPort,resetPin,GPIO_PIN_SET):HAL_GPIO_WritePin(resetPort,resetPin,GPIO_PIN_RESET)
#define cs(x) x?HAL_GPIO_WritePin(csPort,csPin,GPIO_PIN_SET):HAL_GPIO_WritePin(csPort,csPin,GPIO_PIN_RESET)   
#define clk(x) x?HAL_GPIO_WritePin(clkPort,clkPin,GPIO_PIN_SET):HAL_GPIO_WritePin(clkPort,clkPin,GPIO_PIN_RESET)  
#define din(x) x?HAL_GPIO_WritePin(dinPort,dinPin,GPIO_PIN_SET):HAL_GPIO_WritePin(dinPort,dinPin,GPIO_PIN_RESET)




void VFD_init();

void write_6302(unsigned char w_data);

void S1201_show(void);

void S1201_WriteOneChar(unsigned char x, unsigned char chr);

void S1201_WriteStr(unsigned char x,unsigned char *str);
void calculate(uint8_t *val,uint8_t *result);

#endif // !_VFD_H_
